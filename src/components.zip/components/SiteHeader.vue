<template>
  <header class="site-header">
    <div class="container">
      <div class="logo">
        <img src="/img/logo-fields.png" alt="Gestão Fields" />
      </div>
      <nav :class="{ open: menuOpen }">
        <ul>
          <li><a href="#inicio">Início</a></li>
          <li><a href="#sobre">Sobre</a></li>
          <li><a href="#servicos">Serviços</a></li>
          <li><a href="#contato">Contato</a></li>
        </ul>
      </nav>
      <button class="menu-toggle" @click="menuOpen = !menuOpen">☰</button>
    </div>
  </header>
</template>

<script>
export default {
  name: "SiteHeader",
  data() {
    return { menuOpen: false };
  },
};
</script>

<style scoped>
.site-header {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
  padding: 1rem 2rem;
  background: rgba(10, 10, 10, 0.6);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo img {
  height: 75px;
  filter: brightness(0) invert(1);
}

nav ul {
  display: flex;
  gap: 2rem;
  list-style: none;
}

nav a {
  color: #f5f5f5;
  text-decoration: none;
  font-weight: 700;
  font-size: 1rem;
  transition: color 0.3s;
}

nav a:hover {
  color: #1f5f91;
}

.menu-toggle {
  display: none;
  background: none;
  border: none;
  font-size: 2rem;
  color: #fff;
  cursor: pointer;
}

@media (max-width: 768px) {
  nav {
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background-color: rgba(10, 10, 10, 0.9);
    backdrop-filter: blur(8px);
    display: none;
    padding: 1rem 2rem;
  }

  nav.open {
    display: block;
  }

  nav ul {
    flex-direction: column;
    gap: 1rem;
  }

  .menu-toggle {
    display: block;
  }
}
</style>
