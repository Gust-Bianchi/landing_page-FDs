<template>
  <footer class="footer">
    <div class="container">
      <div class="info">
        <img src="/img/logo-fields.png" alt="Gestão Fields" />
        <p>© 2025 Gestão Fields. Todos os direitos reservados.</p>
      </div>
      <nav class="links">
        <a href="#inicio">Início</a>
        <a href="#sobre">Sobre</a>
        <a href="#servicos">Serviços</a>
        <a href="#contato">Contato</a>
      </nav>
    </div>
  </footer>
</template>

<script>
export default {
  name: "FooterSection",
};
</script>

<style scoped>
.footer {
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.02);
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(12px);
  position: relative;
  z-index: 1;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 2rem;
}

.info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.info img {
  height: 40px;
  margin-bottom: 1rem;
  filter: brightness(0) invert(1);
}

.info p {
  font-size: 0.95rem;
  color: #bbbbbb;
}

.links {
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.links a {
  color: #dddddd;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s;
}

.links a:hover {
  color: #1f5f91;
}

@media (max-width: 768px) {
  .container {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .info {
    align-items: center;
  }

  .links {
    justify-content: center;
  }
}
</style>
