<template>
  <section class="sobre-empresa" id="sobre">
    <div class="container">
      <div class="sobre-content">
        <div class="texto">
          <h2>Quem Somos</h2>
          <p>
            A Gestão Fields é especialista em motores de crédito para empresas que exigem performance, inteligência e segurança em suas análises.
            Desenvolvemos soluções sob medida que automatizam decisões com base em dados confiáveis, políticas de risco e integração com os maiores birôs do país.
          </p>
          <p>
            Nossa tecnologia permite aprovações em tempo real, reduz fraudes, melhora a experiência do cliente final e entrega controle total para a sua operação de crédito.
            Tudo isso com precisão e flexibilidade.
          </p>
        </div>
        <div class="imagem">
          <!-- Aqui entra sua imagem -->
          <img src="/img/sobre-img.png" alt="Imagem Institucional" />
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "SobreEmpresa",
};
</script>

<style scoped>
.sobre-empresa {
  position: relative;
  padding: 8rem 2rem;
  background: transparent;
  overflow: hidden;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}

.sobre-content {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 3rem;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(14px);
  border-radius: 20px;
  padding: 4rem;
  animation: fadeUp 1.2s ease forwards;
  transform: translateY(40px);
  opacity: 0;
}

.texto {
  flex: 1;
}

.texto h2 {
  font-size: clamp(2rem, 5vw, 3rem);
  font-weight: 800;
  color: #ffffff;
  margin-bottom: 1.5rem;
}

.texto p {
  font-size: 1.125rem;
  color: #dddddd;
  margin-bottom: 1.5rem;
  line-height: 1.6;
}

.imagem {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.imagem img {
  max-width: 100%;
  height: auto;
  border-radius: 16px;
  object-fit: cover;
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.4);
}

@keyframes fadeUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 900px) {
  .sobre-content {
    flex-direction: column;
    padding: 3rem 2rem;
  }

  .imagem img {
    width: 100%;
    margin-top: 2rem;
  }
}
</style>
