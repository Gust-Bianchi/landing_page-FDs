<template>
  <section class="cta-section" id="cta">
    <div class="container">
      <div class="cta-box">
        <h2>Transforme sua operação de crédito com tecnologia de ponta.</h2>
        <p>Solicite uma demonstração e descubra como podemos impulsionar seus resultados.</p>
        <a
          href="https://api.whatsapp.com/send?phone=5511999999999&text=Olá,+quero+saber+mais+sobre+as+soluções+da+Gestão+Fields"
          class="cta-button"
          target="_blank"
        >
          Fale com um especialista
        </a>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "CTASection",
};
</script>

<style scoped>
.cta-section {
  padding: 8rem 2rem;
  background: transparent;
  overflow: hidden;
  position: relative;
}

.container {
  max-width: 1000px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}

.cta-box {
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(14px);
  border-radius: 20px;
  padding: 4rem 3rem;
  text-align: center;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.4);
  animation: fadeUp 1.2s ease forwards;
  transform: translateY(40px);
  opacity: 0;
}

.cta-box h2 {
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 800;
  color: #ffffff;
  margin-bottom: 1.5rem;
}

.cta-box p {
  font-size: 1.1rem;
  color: #dddddd;
  margin-bottom: 2.5rem;
}

.cta-button {
  display: inline-block;
  background: transparent;
  border: 2px solid #1f5f91;
  color: #1f5f91;
  padding: 1rem 2.5rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: 50px;
  text-decoration: none;
  transition: all 0.4s ease;
  box-shadow: 0 0 12px rgba(31, 95, 145, 0.25);
}

.cta-button:hover {
  background-color: #1f5f91;
  color: #ffffff;
  box-shadow: 0 0 20px rgba(31, 95, 145, 0.5);
  transform: translateY(-2px);
}

@keyframes fadeUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .cta-box {
    padding: 3rem 2rem;
  }
}
</style>
