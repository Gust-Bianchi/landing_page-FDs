<template>
  <section class="servicos-section" ref="section">
    <div class="container" :class="{ visible: isVisible }">
      <h2>Nossas Soluções</h2>
      <div class="grid-servicos">
        <div class="servico" v-for="item in servicos" :key="item.titulo">
          <img :src="item.icone" :alt="item.titulo" />
          <h3>{{ item.titulo }}</h3>
          <p>{{ item.descricao }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "ServicosSection",
  data() {
    return {
      isVisible: false,
      servicos: [
        {
          titulo: "Motor de Crédito Inteligente",
          icone: "/img/credito.svg",
          descricao:
            "Decisões automatizadas com base em dados e regras configuráveis, reduzindo riscos e acelerando aprovações.",
        },
        {
          titulo: "Integração com Birôs",
          icone: "/img/api.svg",
          descricao:
            "Consulta automática a dados da Equifax, Boa Vista e outros birôs por meio de APIs seguras.",
        },
        {
          titulo: "Análise Comportamental",
          icone: "/img/analise.svg",
          descricao:
            "Avaliação de perfil com base em comportamento de pagamento, histórico e recorrência.",
        },
      ],
    };
  },
  mounted() {
    const observer = new IntersectionObserver(
      ([entry]) => {
        this.isVisible = entry.isIntersecting;
      },
      { threshold: 0.2 }
    );
    observer.observe(this.$refs.section);
  },
};
</script>

<style scoped>
.servicos-section {
  padding: 8rem 2rem;
  background: transparent;
  overflow: hidden;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  opacity: 0;
  transform: translateY(50px);
  transition: all 0.8s ease-out;
}

.container.visible {
  opacity: 1;
  transform: translateY(0);
}

h2 {
  font-size: clamp(2rem, 5vw, 3.2rem);
  color: #ffffff;
  margin-bottom: 3rem;
  text-align: center;
  font-weight: 700;
}

.grid-servicos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 2rem;
}

.servico {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(12px);
  border-radius: 16px;
  padding: 2.5rem 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
  text-align: center;
  transition: transform 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.servico:hover {
  transform: translateY(-6px);
}

.servico img {
  height: 60px;
  margin-bottom: 1.5rem;
  filter: brightness(0) invert(1);
}

.servico h3 {
  font-size: 1.3rem;
  color: #ffffff;
  margin-bottom: 0.8rem;
  font-weight: 600;
}

.servico p {
  font-size: 0.95rem;
  color: #cccccc;
  line-height: 1.5;
}
</style>
