<template>
  <section class="hero">
    <!-- 🎥 Vídeo de fundo -->
    <video autoplay muted loop class="background-video">
      <source src="@/assets/large.mp4" type="video/mp4" />
      Seu navegador não suporta vídeo em HTML5.
    </video>

    <!-- Degradê que escurece a parte de baixo do vídeo -->
    <div class="video-fade"></div>


    <!-- 🔲 Camadas decorativas (glow + grid) -->
    <div class="background-layers">
      <div class="glow"></div>
      <div class="grid"></div>
    </div>

    <!-- 🟣 Degradê inferior para transição -->
    <div class="gradient-overlay"></div>

    <!-- 📦 Conteúdo central -->
    <div class="content">
      <h1>GESTÃO FIELDS</h1>
      <p ref="typedText"></p>
      <a
        href="https://api.whatsapp.com/send?phone=5511999999999&text=Ol%C3%A1,+quero+saber+sobre+as+solu%C3%A7%C3%B5es+da+Gest%C3%A3o+Fields"
        class="cta-button"
        target="_blank"
      >
        Fale com a gente
      </a>
    </div>
  </section>
</template>

<script>
export default {
  name: "HeroSection",
  mounted() {
    const el = this.$refs.typedText;
    const fullText = "Soluções de crédito alimentadas por inteligência real.";
    el.textContent = "";
    let i = 0;
    const typing = setInterval(() => {
      el.textContent += fullText.charAt(i);
      i++;
      if (i >= fullText.length) clearInterval(typing);
    }, 30);
  },
};
</script>

<style scoped>
.video-fade {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 400px;
  background: linear-gradient(
    to bottom,
    rgba(8, 8, 8, 0) 0%,
    rgba(8, 8, 8, 0.6) 60%,
    #080808 100%
  );
  z-index: 2;
  pointer-events: none;
}


.hero {
  position: relative;
  min-height: 100svh;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  background: #000;
}

/* 🎥 Vídeo de fundo */
.background-video {
  position: absolute;
  top: 0;
  left: 0;
  min-width: 100%;
  min-height: 100%;
  object-fit: cover;
  z-index: 0;
  opacity: 0.25;
}

/* 🟣 Degradê inferior */
.gradient-overlay {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 700px;
  background: linear-gradient(
    to bottom,
    rgba(10, 10, 10, 0) 0%,
    rgba(10, 10, 10, 0.4) 30%,
    rgba(10, 10, 10, 0.7) 60%,
    #0a0a0a 100%
  );
  z-index: 1;
  pointer-events: none;
}


/* 🔲 Camadas visuais */
.background-layers {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
}

.background-layers .glow {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 800px;
  height: 800px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.12), transparent 60%);
  transform: translate(-50%, -50%);
  filter: blur(100px);
}


/* 📦 Caixa com conteúdo */
.content {
  position: relative;
  z-index: 2;
  backdrop-filter: blur(14px);
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 20px;
  padding: 4rem 3rem;
  text-align: center;
  box-shadow: 0 8px 40px rgba(0,0,0,0.6);
  max-width: 780px;
  width: 100%;
  opacity: 0;
  transform: scale(0.92);
  filter: blur(8px);
  animation: revealBox 1.2s ease forwards, pulse 6s infinite;
  transition: transform 0.3s ease;
}

.content:hover {
  transform: perspective(800px) rotateX(2deg) rotateY(-2deg);
}

@keyframes revealBox {
  to {
    opacity: 1;
    transform: scale(1);
    filter: blur(0);
  }
}

@keyframes pulse {
  0%, 100% { box-shadow: 0 0 15px rgba(255, 255, 255, 0.1); }
  50%      { box-shadow: 0 0 30px rgba(255, 255, 255, 0.22); }
}

h1 {
  font-size: clamp(2rem, 6vw, 4.5rem);
  font-weight: 800;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: #ffffff;
  margin-bottom: 1rem;
}

p {
  font-size: clamp(1rem, 2.5vw, 1.4rem);
  color: #cccccc;
  margin-bottom: 2.5rem;
  font-weight: 300;
  min-height: 3rem;
}

.cta-button {
  display: inline-block;
  background: transparent;
  border: 2px solid #1f5f91;
  color: #1f5f91;
  padding: 1rem 2.8rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: 50px;
  text-decoration: none;
  transition: all 0.4s ease;
  box-shadow: 0 0 12px rgba(31, 95, 145, 0.25);
  white-space: nowrap;
}

.cta-button:hover {
  background-color: #1f5f91;
  color: #ffffff;
  box-shadow: 0 0 20px rgba(31, 95, 145, 0.5);
  transform: translateY(-2px);
}
</style>
