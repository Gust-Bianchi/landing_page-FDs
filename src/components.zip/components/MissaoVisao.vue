<template>
  <section class="missao-visao" ref="section">
    <div class="container" :class="{ visible: isVisible }">
      <h2>Missão, Visão e Valores</h2>
      <div class="cards">
        <div class="card" v-for="(item, index) in blocos" :key="index">
          <img :src="item.icone" :alt="item.titulo" />
          <h3>{{ item.titulo }}</h3>
          <p>{{ item.descricao }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "MissaoVisao",
  data() {
    return {
      isVisible: false,
      blocos: [
        {
          titulo: "Missão",
          icone: "/img/missao.svg",
          descricao:
            "Oferecer inteligência de crédito personalizada, eficiente e precisa, promovendo decisões seguras e assertivas.",
        },
        {
          titulo: "Visão",
          icone: "/img/visao.svg",
          descricao:
            "Ser referência nacional em motores de crédito inteligentes, reconhecida pela inovação e impacto nos resultados.",
        },
        {
          titulo: "Valores",
          icone: "/img/valores.svg",
          descricao:
            "Compromisso com performance, ética, segurança e tecnologia de ponta, entregando soluções com excelência.",
        },
      ],
    };
  },
  mounted() {
    const observer = new IntersectionObserver(
      ([entry]) => {
        this.isVisible = entry.isIntersecting;
      },
      { threshold: 0.2 }
    );
    observer.observe(this.$refs.section);
  },
};
</script>

<style scoped>
.missao-visao {
  padding: 8rem 2rem;
  background: transparent;
  overflow: hidden;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  text-align: center;
  opacity: 0;
  transform: translateY(50px);
  transition: all 0.8s ease-out;
}

.container.visible {
  opacity: 1;
  transform: translateY(0);
}

h2 {
  font-size: clamp(2rem, 5vw, 3.2rem);
  color: #ffffff;
  margin-bottom: 3rem;
  font-weight: 700;
}

.cards {
  display: flex;
  justify-content: center;
  gap: 2rem;
  flex-wrap: wrap;
}

.card {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(14px);
  border-radius: 16px;
  padding: 2.5rem 2rem;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.08);
  text-align: center;
  transition: transform 0.3s ease;
  max-width: 300px;
  flex: 1 1 280px;
}

.card:hover {
  transform: translateY(-6px);
}

.card img {
  height: 60px;
  margin-bottom: 1.5rem;
  filter: brightness(0) invert(1);
}

.card h3 {
  font-size: 1.3rem;
  color: #ffffff;
  margin-bottom: 0.8rem;
  font-weight: 600;
}

.card p {
  font-size: 0.95rem;
  color: #cccccc;
  line-height: 1.6;
}
</style>
