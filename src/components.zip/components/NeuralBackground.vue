<template>
  <svg class="neural-net" viewBox="0 0 1000 800" preserveAspectRatio="xMidYMid slice">
    <!-- Nós -->
    <circle cx="500" cy="400" r="2" />
    <circle cx="650" cy="250" r="2" />
    <circle cx="800" cy="400" r="2" />
    <circle cx="600" cy="580" r="2" />
    <circle cx="400" cy="550" r="2" />
    <circle cx="300" cy="350" r="2" />
    <circle cx="420" cy="200" r="2" />
    <circle cx="700" cy="150" r="2" />

    <!-- Conexões -->
    <line x1="500" y1="400" x2="650" y2="250" />
    <line x1="650" y1="250" x2="800" y2="400" />
    <line x1="800" y1="400" x2="600" y2="580" />
    <line x1="600" y1="580" x2="400" y2="550" />
    <line x1="400" y1="550" x2="300" y2="350" />
    <line x1="300" y1="350" x2="420" y2="200" />
    <line x1="420" y1="200" x2="650" y2="250" />
    <line x1="700" y1="150" x2="650" y2="250" />
  </svg>
</template>

<script>
export default {
  name: "NeuralBackground",
};
</script>

<style scoped>
.neural-net {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: -10;
  pointer-events: none;
  stroke: rgba(31, 95, 145, 0.12);
  fill: rgba(31, 95, 145, 0.25);
  stroke-width: 1;
  animation: floatNet 16s ease-in-out infinite;
}

@keyframes floatNet {
  0%, 100% {
    transform: translateY(0) scale(1);
  }
  50% {
    transform: translateY(12px) scale(1.01);
  }
}
</style>
