<template>
  <section class="equifax-section" id="equifax">
    <div class="container">
      <div class="card">
        <div class="texto">
          <h2>Parceria com a Equifax</h2>
          <p>
            A Gestão Fields é parceira da Equifax, uma das maiores empresas de dados e inteligência de crédito do mundo.
            Essa parceria fortalece nossa capacidade de oferecer análises precisas, confiáveis e em tempo real para nossos clientes.
          </p>
        </div>
        <div class="logo">
          <img src="/img/logo-equifax.png" alt="Logo Equifax" />
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "EquifaxSection",
};
</script>

<style scoped>
.equifax-section {
  padding: 8rem 2rem;
  background: transparent;
  position: relative;
  overflow: hidden;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}

.card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 3rem;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(14px);
  border-radius: 20px;
  padding: 4rem;
  animation: fadeUp 1.2s ease forwards;
  transform: translateY(40px);
  opacity: 0;
}

.texto {
  flex: 1;
}

.texto h2 {
  font-size: clamp(2rem, 5vw, 3rem);
  font-weight: 800;
  color: #ffffff;
  margin-bottom: 1.5rem;
}

.texto p {
  font-size: 1.125rem;
  color: #dddddd;
  line-height: 1.6;
}

.logo {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.logo img {
  max-width: 260px;
  filter: brightness(0) invert(1);
  opacity: 0.9;
}

@keyframes fadeUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 900px) {
  .card {
    flex-direction: column;
    padding: 3rem 2rem;
  }

  .logo img {
    margin-top: 2rem;
    width: 80%;
  }
}
</style>
