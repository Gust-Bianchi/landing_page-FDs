<template>
  <a
    :href="whatsLink"
    class="whatsapp-float"
    target="_blank"
    rel="noopener"
    aria-label="Fale pelo WhatsApp"
  >
    <img src="/img/whatsapp.png" alt="WhatsApp" />
  </a>
</template>

<script>
export default {
  name: 'WhatsAppFloat',
  data() {
    return {
      whatsLink:
        'https://api.whatsapp.com/send?phone=5511999999999&text=Ol%C3%A1%2C+tenho+interesse+nas+solu%C3%A7%C3%B5es+da+Gest%C3%A3o+Fields.'
    };
  }
};
</script>

<style scoped>
.whatsapp-float {
  position: fixed;
  bottom: 25px;
  right: 25px;
  width: 60px;
  height: 60px;
  z-index: 1000;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.whatsapp-float:hover {
  transform: scale(1.1);
}

.whatsapp-float img {
  width: 100%;
  height: 100%;
}

@media (max-width: 480px) {
  .whatsapp-float {
    width: 50px;
    height: 50px;
    bottom: 20px;
    right: 20px;
  }
}
</style>
