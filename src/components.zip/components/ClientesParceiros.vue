<template>
  <section class="clientes-parceiros">
    <div class="container">
      <h2>Clientes & Parceiros</h2>
      <div
        class="carrossel"
        ref="carrossel"
      >
        <div class="logo-track" :style="{ transform: `translateX(${scrollX}px)` }">
          <div
            class="logo-item"
            v-for="(logo, index) in duplicatedLogos"
            :key="index"
          >
            <img :src="logo.src" :alt="logo.nome" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "ClientesParceiros",
  data() {
    return {
      logos: [
        { nome: "Cliente 1", src: "/img/logo1.svg" },
        { nome: "Cliente 2", src: "/img/logo2.svg" },
        { nome: "Cliente 3", src: "/img/logo3.svg" },
        { nome: "Cliente 4", src: "/img/logo4.svg" },
        { nome: "Cliente 5", src: "/img/logo5.svg" },
        { nome: "Cliente 6", src: "/img/logo6.svg" },
      ],
      scrollX: 0,
      isDragging: false,
      startX: 0,
      lastScrollX: 0,
      speed: 0.5,
      animationFrame: null,
    };
  },
  computed: {
    duplicatedLogos() {
      return [...this.logos, ...this.logos, ...this.logos]; // loop suave
    },
  },
  mounted() {
    this.animate();
  },
  beforeUnmount() {
    cancelAnimationFrame(this.animationFrame);
  },
  methods: {
    animate() {
      if (!this.isDragging) {
        this.scrollX -= this.speed;
        const totalWidth = this.$refs.carrossel.scrollWidth / 3;
        if (Math.abs(this.scrollX) >= totalWidth) {
          this.scrollX = 0; // reset para loop
        }
      }
      this.animationFrame = requestAnimationFrame(this.animate);
    },
    pause() {
      this.speed = 0;
    },
    resume() {
      this.speed = 0.5;
    },
    startDrag(e) {
      this.isDragging = true;
      this.startX = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
      this.lastScrollX = this.scrollX;
    },
    drag(e) {
      if (!this.isDragging) return;
      const x = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
      const delta = x - this.startX;
      this.scrollX = this.lastScrollX + delta;
    },
    stopDrag() {
      this.isDragging = false;
    },
  },
};
</script>

<style scoped>
.clientes-parceiros {
  padding: 8rem 2rem;
  background: transparent;
  overflow: hidden;
  position: relative;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  text-align: center;
}

h2 {
  font-size: clamp(2rem, 5vw, 3rem);
  color: #ffffff;
  margin-bottom: 3rem;
  font-weight: 700;
}

.carrossel {
  overflow: hidden;
  width: 100%;
  cursor: grab;
}

.logo-track {
  display: flex;
  gap: 2rem;
  transition: transform 0.1s linear;
  will-change: transform;
}

.logo-item {
  width: 140px;
  height: 180px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(12px);
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: transform 0.3s ease;
}

.logo-item img {
  max-height: 130px;
  max-width: 100px;
  object-fit: contain;
  filter: brightness(0) invert(1);
}

.logo-item:hover {
  transform: scale(1.05);
}
</style>
